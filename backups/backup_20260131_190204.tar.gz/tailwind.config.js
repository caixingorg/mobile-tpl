/*
  * @Author: flynn * @Date: 2024-04-01 09:45:57
 * @LastEditors: flynn
 * @LastEditTime: 2024-04-01 09:48:44
 * @description: 心平气和
 */
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
    "./src/**/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

